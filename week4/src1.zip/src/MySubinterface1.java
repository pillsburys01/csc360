
public interface MySubinterface1 
	extends MyInterface1, MyInterface2 {
	

}

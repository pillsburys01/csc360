
public interface MyInterface2 {
	int MY_CONSTANT = 2;
	Rectangle f(int x);
	static int addOne(int y) { return y + 1; }
}

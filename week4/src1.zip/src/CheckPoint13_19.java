
public class CheckPoint13_19 {
	public static void main(String[] args) {
		Integer n1 = new Integer(3);
		Object n2 = new Integer(4);
		//System.out.println(n1.compareTo(n2));
	}
}

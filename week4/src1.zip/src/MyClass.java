
public abstract class MyClass extends Circle implements MySubinterface1 {
	public abstract int g();

}

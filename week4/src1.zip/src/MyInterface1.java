
public interface MyInterface1 {
	int MY_CONSTANT = 1;
	GeometricObject f(int x);

}
